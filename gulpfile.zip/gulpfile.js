'use strict';

var gulp = require('gulp');
var util=require('util');
var $ = require('gulp-load-plugins')();



var filePath = {
    index: 'app/index',
    about: 'app/about'
};

var config = {
    tmp:'.tmp',
    src:'app'
};


gulp.task('inject', function() {

    return gulp.src('app/*.html')
        .pipe($.inject(gulp.src(filePath.index + '/**/*.js'), {
            name: 'inject:index'
        }))
        .pipe($.inject(gulp.src(filePath.about + '/**/*.js'), {
            name: 'inject:about'
        }))
        .pipe(gulp.dest('.tmp/'))

});

gulp.task('build', ['inject'], function() {

    //var assets = $.useref.assets();
    var jsFilter = $.filter('**/*.js');
    var cssFilter = $.filter('**/*.css');

    var assets = $.useref.assets({
        searchPath: './'
    });
    return gulp.src('.tmp/*.html')
        .pipe(assets)
        .pipe(jsFilter)
        .pipe($.uglify())
        .pipe(jsFilter.restore())
        .pipe($.rev())
        .pipe(assets.restore())
        .pipe($.useref())
        .pipe($.revReplace())
        .pipe(gulp.dest('dist'));
});



var browserSync = require('browser-sync');

// var middleware = require('./proxy');

function browserSyncInit(baseDir, files, isSpecRunner, browser) {
    browser = browser === undefined ? 'default' : browser;

    var routes = null;
    if (baseDir === config.src || (util.isArray(baseDir) && baseDir.indexOf(config.src) !== -1)) {
        routes = {
            '/bower_components': 'bower_components',
            '/node_modules': 'node_modules'
        };
    }

    var startPath = '/';
    if (isSpecRunner) {
        startPath += config.specRunnerFile;
    }

    browserSync.instance = browserSync.init(files, {
        startPath: startPath,
        server: {
            baseDir: baseDir,
            // middleware: middleware,
            routes: routes
        },
        browser: browser,
        ghostMode: {
            clicks: true,
            location: false,
            forms: true,
            scroll: true
        },
        injectChanges: true,
        reloadDelay: 1000
    });
}


gulp.task('watch',function(){
    gulp.watch('app/**/*.*',['inject']);
});



gulp.task('serve', ['inject','watch'], function() {
    browserSyncInit([
        config.tmp + '',
        config.src
    ], [
        config.tmp + '/**/*.css',
        config.src + '/{about,index}/*.js',
        config.src + 'src/assets/images/**/*',
        config.tmp + '/**/*.html'

    ]);
});
